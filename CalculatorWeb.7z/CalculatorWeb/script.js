function onBlurTest(e)
{
	if(e.value > 100)
	{
		e.value = "100";
	}
	else if(e.value < -100)
	{
		e.value = "-100";
	}
}

function calculate(numA, numB, operand)
{
	let result = "";
	let a = parseInt(numA);
	let b = parseInt(numB);
	switch(operand)
	{
		case "+":
			result = a + b;
		break;
		case "-":
			result = a - b;
		break;
		case "*":
			result = a * b;
		break;
		case "/":
			if(b != 0)
			{
				result = a / b;
			}
			else
			{
				result = "Could not divide by zero!";
			}
		break;
	}
	
	return result;
}

function PrintCalculate(numA, numB, operand)
{
	let result = calculate(numA, numB, operand);
	document.getElementById("result").value = result;
}